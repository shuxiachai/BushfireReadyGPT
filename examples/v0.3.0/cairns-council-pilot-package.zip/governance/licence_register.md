# Licence Register

This register is a planning aid, not legal advice. Commercial deployment requires source-by-source review.

## Australian Bureau of Statistics website and ASGS / SA2 data

- Provider: Australian Bureau of Statistics
- Source URL: https://www.abs.gov.au/website-privacy-copyright-and-disclaimer
- Licence position: CC BY 4.0 for most ABS website material unless otherwise stated.
- Commercial position: Potentially usable commercially with attribution when the specific product is CC BY 4.0; verify product-level exclusions.
- Attribution required: Source: Australian Bureau of Statistics / Based on Australian Bureau of Statistics data
- Caching position: Local caching is acceptable for prototype traceability, but production use should record source URL, download date and product licence.
- Exclusions / risks: Commonwealth Coat of Arms, ABS logo, trademarks, microdata, third-party content and product-specific exclusions are not covered by default CC BY reuse.
- Current project use: SA2 population/context data, ASGS allocation files and LGA reference context.
- Review status: Needs legal/product-level review before commercial release.

## Bureau of Meteorology website, warnings and data services

- Provider: Bureau of Meteorology
- Source URL: https://www.bom.gov.au/copyright
- Licence position: Mixed. Some material may be CC BY or covered by data licence agreements; where no stated terms apply, commercial reuse is not permitted without permission.
- Commercial position: Do not cache, republish or commercialise BoM warnings/data unless the specific product terms or a data licence agreement allow it.
- Attribution required: Bureau of Meteorology, © Commonwealth of Australia, or wording required by the specific licence.
- Caching position: Current prototype links/checks entry-point reachability only. Do not store live warning content without licence review.
- Exclusions / risks: Radar images, high-resolution maps, specialised data, Indigenous weather knowledge, logos, marks and some real-time products may have restrictions.
- Current project use: Official source link and reachability status only; no warning content ingestion.
- Review status: High-priority licence review required before live data integration.

## Queensland Government preparedness pages and current warning entry points

- Provider: Queensland Government
- Source URL: https://www.qld.gov.au/legal/copyright
- Licence position: CC BY 4.0 by default unless otherwise noted.
- Commercial position: Potentially reusable with attribution where CC BY 4.0 applies; verify agency-specific pages and exclusions.
- Attribution required: © State of Queensland, licensed under CC BY 4.0, plus source page URL where practical.
- Caching position: The two declared static preparedness pages are cached locally, parsed and embedded for optional RAG. Raw pages and the vector index are excluded from Git. Live warning content remains link-only.
- Exclusions / risks: Government logos, coat of arms, trademarks, third-party material and pages with alternative notices are excluded.
- Current project use: Local RAG retrieval over two static preparedness pages, citations in draft reports, and official warning-source reachability checks.
- Review status: Preparedness pages reviewed 2026-08-21; re-check page metadata and exclusions before commercial deployment.

## NSW RFS Bush Fire Survival Plan page

- Provider: NSW Rural Fire Service
- Source URL: https://www.rfs.nsw.gov.au/plan-and-prepare/bush-fire-survival-plan
- Licence position: NSW RFS states that most website material is CC BY 4.0, but its published conditions also include narrower storage and commercialisation language.
- Commercial position: Treat the current position as ambiguous. Obtain written or legal confirmation before shipping cached text, embeddings or derived commercial content.
- Attribution required: © State of New South Wales (NSW Rural Fire Service). For current information go to www.rfs.nsw.gov.au.
- Caching position: Cached and parsed only in the local interview/research prototype. Raw HTML and the index are excluded from Git.
- Exclusions / risks: Logos, third-party material and page-specific conditions are excluded; the coexistence of CC BY and narrower reuse wording needs legal resolution.
- Current project use: Static preparedness retrieval and attributed evidence links in draft reports.
- Review status: Page and copyright notice reviewed 2026-08-21; permission review required before commercial redistribution.

## CFA Your Bushfire Plan page

- Provider: Country Fire Authority Victoria
- Source URL: https://www.cfa.vic.gov.au/plan-prepare/before-and-during-a-fire/your-bushfire-plan
- Licence position: State of Victoria copyright applies; no page-specific open licence was identified for this HTML page.
- Commercial position: Do not redistribute cached or transformed page content without written permission or confirmed licence terms.
- Attribution required: © State of Victoria (Country Fire Authority), page title and source URL.
- Caching position: Cached and parsed only in the local interview/research prototype. Raw HTML and the index are excluded from Git.
- Exclusions / risks: The general disclaimer is not a reuse licence; branding, images and third-party materials may have separate owners.
- Current project use: Static preparedness retrieval and attributed evidence links in draft reports.
- Review status: Page and disclaimer reviewed 2026-08-21; permission required before redistribution.

## DFES Prepare for a bushfire page

- Provider: Department of Fire and Emergency Services Western Australia
- Source URL: https://dfes.wa.gov.au/hazard-information/bushfire/prepare
- Licence position: DFES reserves copyright and requires written permission for reproduction or reuse, except where a statutory exception applies.
- Commercial position: Do not redistribute cached text, embeddings or derived commercial content without written permission.
- Attribution required: Department of Fire and Emergency Services Western Australia, page title and source URL, subject to permission terms.
- Caching position: Cached and parsed only for private study/research in the local prototype. Raw HTML and the index are excluded from Git.
- Exclusions / risks: Government branding, third-party content and the page text are not covered by an identified open licence.
- Current project use: Static preparedness retrieval and attributed evidence links in draft reports.
- Review status: Page and copyright notice reviewed 2026-08-21; permission required before broader use.

## SA CFS Bushfire Survival Plan page

- Provider: South Australian Country Fire Service
- Source URL: https://www.cfs.sa.gov.au/plan-prepare/before-a-fire-be-prepared/make-a-plan/bushfire-survival-plan/
- Licence position: CFS website content is CC BY 4.0 except emblems, images, trademarks and identified third-party material.
- Commercial position: Reuse is permitted with attribution where the CC BY 4.0 notice applies and exclusions are respected.
- Attribution required: South Australian Country Fire Service, page title, date sourced and source URL, licensed under CC BY 4.0.
- Caching position: Static page text is cached locally, parsed and embedded for optional RAG. Raw HTML and the index are excluded from Git.
- Exclusions / risks: Government emblems, images, trademarks and third-party content are excluded from the open licence.
- Current project use: Static preparedness retrieval and attributed evidence links in draft reports.
- Review status: Page and copyright notice reviewed 2026-08-21.

## Tasmania Fire Service Community Bushfire Protection Plans page

- Provider: Tasmania Fire Service
- Source URL: https://www.fire.tas.gov.au/Show?pageId=communityProtectionPlan
- Licence position: Tasmania Fire Service permits personal, non-commercial use and otherwise restricts storage, distribution and reproduction without authorisation.
- Commercial position: Do not redistribute or commercialise cached text, embeddings or derived content without permission.
- Attribution required: Tasmania Fire Service, page title and source URL, subject to permission terms.
- Caching position: Cached and parsed only for personal, non-commercial research in the local prototype. Raw HTML and the index are excluded from Git.
- Exclusions / risks: The page does not carry an identified open licence; storage and distribution rights are restricted.
- Current project use: Static preparedness retrieval and attributed evidence links in draft reports.
- Review status: Page and copyright notice reviewed 2026-08-21; permission required before broader use.

## ACT ESA Bushfires page

- Provider: ACT Emergency Services Agency / Justice and Community Safety Directorate
- Source URL: https://esa.act.gov.au/be-emergency-ready/bushfires
- Licence position: ACT Government and JACS default website terms license content under CC BY 4.0 unless stated otherwise.
- Commercial position: Reuse is permitted with attribution where CC BY 4.0 applies and exclusions are respected.
- Attribution required: © Australian Capital Territory, page title and source URL, licensed under CC BY 4.0.
- Caching position: Static page text is cached locally, parsed and embedded for optional RAG. Raw HTML and the index are excluded from Git.
- Exclusions / risks: ACT crests, agency logos, trademarks, third-party material and content with specific alternative terms are excluded.
- Current project use: Static preparedness retrieval and attributed evidence links in draft reports.
- Review status: Page and JACS copyright policy reviewed 2026-08-21.

## NT PFES Bushfire Safety page

- Provider: Northern Territory Police, Fire and Emergency Services
- Source URL: https://pfes.nt.gov.au/fire-and-rescue-service/fire-safety/bushfire-safety
- Licence position: NTPFES permits reproduction for non-commercial purposes; alteration or other use requires express written consent.
- Commercial position: Do not redistribute, adapt or commercialise cached text, embeddings or derived content without written consent.
- Attribution required: © Northern Territory Government / NTPFES, page title and source URL.
- Caching position: Cached and parsed only for non-commercial research in the local prototype. Raw HTML and the index are excluded from Git.
- Exclusions / risks: Adaptation and commercial use are restricted; logos, crests and third-party content require separate permission.
- Current project use: Static preparedness retrieval and attributed evidence links in draft reports.
- Review status: Page and NTPFES copyright notice reviewed 2026-08-21; consent required before commercial use.

## Australian state and territory government emergency services websites (NSW, VIC, WA, SA, TAS, NT, ACT)

- Provider: NSW Government / Victorian Government / Government of Western Australia / Government of South Australia / Tasmanian Government / Northern Territory Government / ACT Government
- Source URL: https://www.australia.gov.au/about-australia/australian-government/emergency-management
- Licence position: State and territory government websites typically apply Creative Commons (CC BY 4.0 or CC BY 3.0 AU) unless otherwise noted. Each agency page may carry different terms; verify before reuse.
- Commercial position: Link-only use and attribution are generally low risk under standard CC BY conditions; caching warning content or reproducing agency material requires page-level review.
- Attribution required: © State/Territory Government [name], licensed under CC BY [version], with source page URL where practical.
- Caching position: This aggregate entry covers live warning/status entry points only. Static RAG pages are documented separately above. Do not store or republish live warning content without page-specific review.
- Exclusions / risks: Government crests, logos, trademarks, third-party images and pages with alternative copyright notices are excluded. ACT and NT pages may carry different terms from mainland state governments.
- Current project use: Official source register and reachability checks for NSW RFS, VicEmergency, Emergency WA, Alert SA, TasALERT, Tasmania Fire Service, ACT ESA and NT PFES.
- Review status: Needs page-level legal review for each agency before commercial deployment or content reproduction.

## Cairns Regional Council website and disaster information pages

- Provider: Cairns Regional Council
- Source URL: https://www.cairns.qld.gov.au/home/legals
- Licence position: Council-owned material is copyright and authorisation is required before reproduction, storage or transmission.
- Commercial position: Treat as link-only unless written permission or page-specific licence is obtained.
- Attribution required: Cairns Regional Council, with URL and permission terms if granted.
- Caching position: Do not cache or reproduce council content in a commercial product without authorisation.
- Exclusions / risks: Council terms are more restrictive than generic CC BY assumptions; legal permission may be needed.
- Current project use: Official source link and status check entry point only.
- Review status: Permission required before commercial content reuse.

## Triple Zero website

- Provider: Australian Government / Triple Zero
- Source URL: https://www.triplezero.gov.au/
- Licence position: Review required. Use as an emergency contact reference rather than a content source.
- Commercial position: Safe to reference 000 as Australia emergency number; do not imply endorsement or reproduce website content without checking terms.
- Attribution required: Triple Zero website URL where used as an information source.
- Caching position: Link-only in current prototype.
- Exclusions / risks: Do not use branding or imply affiliation.
- Current project use: Safety boundary and emergency number reminder.
- Review status: Review required before commercial marketing material.

## Notes

- This register is not legal advice.
- Commercial deployment needs a source-by-source legal and product review.
- Live emergency warnings, fire bans and evacuation orders should remain authoritative at official emergency services.