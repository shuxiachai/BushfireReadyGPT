# Data Register

This register summarises local data sources used by the pilot package. Licence and terms of use must be reviewed before commercial deployment.

## ABS Data by Region / Digital Atlas SA2 population layer

- Provider: Australian Bureau of Statistics
- URL: https://geo.abs.gov.au/arcgis/rest/services/Hosted/ABS_Population_and_people_by_2021_SA2_Nov_2023/FeatureServer/1
- Licence position: Verify ABS conditions of use before commercial deployment
- Used for: Community profile indicators including population, older people percentage, and language support needs.
- Limitations: Does not provide real-time emergency conditions or no-car household transport vulnerability in the current layer.
- Local file status: data_australia/processed/sa2_profiles_all.csv: updated 2026-08-22 10:51:54; data_australia/raw/abs_population_people_sa2_all.json: updated 2026-08-22 10:51:40

## ABS ASGS 2021 SA2 boundary layer

- Provider: Australian Bureau of Statistics
- URL: https://geo.abs.gov.au/arcgis/rest/services/ASGS2021/SA2/MapServer/0
- Licence position: Verify ABS conditions of use before commercial deployment
- Used for: Offline SA2/SA3/SA4 map selection and geographic evidence display.
- Limitations: SA2/SA3/SA4 statistical areas are not the same as official LGA boundaries.
- Local file status: data_australia/processed/sa2_boundaries_all.geojson: updated 2026-08-22 10:52:04; data_australia/processed/sa2_boundaries_by_state: 10 files

## ABS ASGS Edition 3 allocation and correspondence files

- Provider: Australian Bureau of Statistics
- URL: https://www.abs.gov.au/statistics/standards/australian-statistical-geography-standard-asgs-edition-3/jul2021-jun2026/access-and-downloads/allocation-files
- Licence position: Verify ABS conditions of use before commercial deployment
- Used for: Official geography hierarchy checks, LGA reference context and data traceability for pilot reports.
- Limitations: Allocation files are planning context only; LGA and SA2 boundaries may not align cleanly enough for operational decisions without GIS review.
- Local file status: data_australia/raw/asgs_allocations: 3 files; data_australia/processed/asgs_allocations/sa2_to_sa3_sa4_state_2021.csv: updated 2026-08-21 17:05:06; data_australia/processed/asgs_allocations/lga_2025_summary.csv: updated 2026-08-21 17:05:06; data_australia/processed/asgs_allocations/lga_2024_to_2025_correspondence.csv: updated 2026-08-21 17:05:06; data_australia/processed/asgs_allocations/metadata.json: updated 2026-08-21 17:05:06

## Australian state and territory official emergency and preparedness sources

- Provider: State and territory governments, fire services, local councils (see official_sources.yml for per-source attribution)
- URL: https://www.australia.gov.au/about-australia/australian-government/emergency-management
- Licence position: Terms vary by agency and page; use the page-level licence register and obtain review where reuse is restricted or unclear.
- Used for: Official source register for all states and territories. Report verification links for fire services, emergency portals, local councils and Bureau of Meteorology.
- Limitations: The app links to official sources but does not issue or verify live warnings, fire bans or evacuation orders.
- Local file status: data_australia/official_sources.yml: updated 2026-08-21 17:05:06

## Bureau of Meteorology warning and data service references

- Provider: Bureau of Meteorology
- URL: https://www.bom.gov.au/resources/data-services
- Licence position: Verify BoM copyright and data service terms before commercial use.
- Used for: Weather and warning source attribution in preparedness reports.
- Limitations: The current app does not ingest live BoM warnings or fire danger ratings.
- Local file status: data_australia/official_sources.yml: updated 2026-08-21 17:05:06

## Optional static official preparedness RAG corpus

- Provider: Australian state and territory fire/emergency agencies covering QLD, NSW, VIC, WA, SA, TAS, ACT and NT (see rag/sources.yml)
- URL: https://www.qld.gov.au/emergency/dealing-disasters/disaster-types/bushfires
- Licence position: Reuse terms are tracked per page; restricted or ambiguous entries require permission review before redistribution.
- Used for: Local hybrid dense + BM25 retrieval of attributed cross-jurisdiction preparedness passages for draft reports.
- Limitations: Static planning references only; similarity does not establish currency, correctness, live conditions or operational applicability.
- Local file status: data_australia/rag/sources.yml: updated 2026-08-22 09:39:47; data_australia/rag/raw: 11 files; data_australia/rag/index: 2 files
